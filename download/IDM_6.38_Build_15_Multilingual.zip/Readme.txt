Apply patch, reg with key:

DDDDM-DDDDD-DDDDX-DDDDX
=================

